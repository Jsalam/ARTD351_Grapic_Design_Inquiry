INSTRUCTIONS

These instructions are for testing the color palettes exported from color picker web app (http://smartartifact.com/artd351/assignment_2/) in rgb format.

The file colorMap.jar is an executable file that should run on any computer with Java 1.8 or later. It displays the color palettes stored in the companion folder 'colorPalettes'. If you want to know which Java version do you have in your computer check: https://www.java.com/en/download/help/version_manual.xml


PROCEDURE

- Compose you palette in 'http://smartartifact.com/artd351/assignment_2/' and  export it in rgb format. This web app saves a palette.txt file in your downloads folder.
- Put the file inside the colorPalettes folder.
- Double click colorMap.jar. You should get a small window with five color palettes. Four of them are by default saved in the colorPalettes folder.



   